# Hacking Tool Kits

I made a project that is a collection of hacking tools written in Python, I hope it will be useful to you :)

# Content

Ddos, Brute Force , Vpn checker , Vulnerability analysis , Trojan maker , Toolkit searcher , Port scanner , Firewall detector , Exploit searcher , Database stealer


# Images 

![cryonicx](https://media.discordapp.net/attachments/867052919332536360/871476628931354664/Screenshot_2021-08-01_223622.png?width=1025&height=424)

![cryonicX](https://media.discordapp.net/attachments/867052919332536360/871477113478320168/Screenshot_2021-08-01_223841.png)

![cryonicX](https://media.discordapp.net/attachments/867052919332536360/871477373244149760/Screenshot_2021-08-01_223943.png?width=1025&height=394)

![cryonicX](https://media.discordapp.net/attachments/870335421601681438/870792676402950215/Screenshot_2021-07-31_011844.png?width=1025&height=433)

![cryonicx](https://media.discordapp.net/attachments/870335421601681438/870796514161741824/Screenshot_2021-07-31_013357.png?width=1025&height=430)

![cryonicx](https://media.discordapp.net/attachments/867052919332536360/871478027245207592/Screenshot_2021-08-01_224215.png)

![cryonicx](https://media.discordapp.net/attachments/867052919332536360/871478267578826772/Screenshot_2021-08-01_224317.png?width=1025&height=362)

![cryonicx](https://media.discordapp.net/attachments/867052919332536360/871479420903391242/Screenshot_2021-08-01_224749.png)
....

# Installation

````
sudo apt install python3
````

![python](https://media.discordapp.net/attachments/867052919332536360/871481596874752030/Screenshot_2021-08-01_225633.png)

then;

````
sudo apt-get install python3-scapy
````
![hakan](https://media.discordapp.net/attachments/871383768458481705/871485609078849606/unknown.png)




# Usage

Start Script
````
sudo python3 main.py
````


![cryonicx knk](https://media.discordapp.net/attachments/870335421601681438/870795608703791104/Screenshot_2021-07-31_013024.png)


# Information

* This is a personal development, please respect its philosophy and don't use it for bad things!

* You can run this script only on debian system.


# Developer

* *CRYONICX & REF*

* Discord: [CRYONICX#0044](https://discord.com/users/690517771045437530) &  [Ref#0044](https://discord.com/users/381121361474748426)
* Github: [@CryonicX](https://github.com/CryonicsX) & [@Reflechir](https://github.com/Reflechir)



# Show Your Support

If the project helped you, you can support me by giving ⭐️!

# License

Copyright © 2021 [CRYONICX & REF](https://github.com/CryonicsX)<br />
This project is [MIT](https://github.com/CryonicsX/Hacking-tools/blob/main/LICENSE) licensed.
