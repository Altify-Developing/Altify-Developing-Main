# Nike-Account-Generator-written-in-Csharp

Bug: 
1. User-Agent from BOGUS sometimes is unusable causing the form of the website to change. Put in your own User-Agent to be sure.

Things to add:
1. SMSCODE API support
2. Rewrite the loop to have better error-handle
3. Proxy Support

update: 
very interesting prototype that I abandoned. 
I fixed everything for the private repo
Looking for people to test, currently have 2 people testing.
