# Roblox Account Generator 
Simple Roblox Account Generator built in .NET Framework 4.8
* Multi-Threading
* Proxies

# NuGet Packages

* [Newtonsoft.Json](https://www.nuget.org/packages/Newtonsoft.Json/) Json.NET is a popular high-performance JSON framework for .NET
* [AntiCaptchaAPI](https://www.nuget.org/packages/AntiCaptchaAPI/) Simple Wrapper for https://anti-captcha.com

# Usage

* Fill  `proxies.txt` with proxies
* Add your Anti-Captcha Solver or Solved Fun Captcha in the code
and you are ready to go!

## Showcase

![](https://user-images.githubusercontent.com/40140975/139946032-4332b9c6-276c-4af9-bcd0-c66ab2fb64ff.mp4)


## Build

* To be added
