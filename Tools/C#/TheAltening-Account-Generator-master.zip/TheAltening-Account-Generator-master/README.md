# TheAltening Account Generator
![alt text](https://i.imgur.com/Ijsv0cO.png "Logo")

Generates Alts for you Using the TheAltening API

## Thanks to guys at TheAltening for providing a [public api](https://panel.thealtening.com/#api)

## Special Thanks to:
- OQ
- Xevier
