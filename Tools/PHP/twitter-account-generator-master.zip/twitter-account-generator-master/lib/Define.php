<?php 
define('PATH_ACCOUNT_JSON', './account.json');
define('PATH_USERNAMES_EXAMPLE', './storage/usernames_example.txt');
define('PATH_GENERATED_ACCOUNT', './log/generated_account.txt');

define('ERROR_FETAIL_GET_AUTH_CODE', '認証処理で失敗しました。ウィンドウサイズを大きくするなど調整してみてください。');
define('ERROR_RETRY_AUTH', '認証コードの取得に失敗しました。リトライします。');
