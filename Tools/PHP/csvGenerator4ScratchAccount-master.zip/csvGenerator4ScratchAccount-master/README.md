# csvGenerator4ScratchAccount

![logo](https://github.com/mjk0513/csvGenerator4ScratchAccount/blob/master/images/logo.png)

This project is used for every Scratch teacher's account holder.  
Access to this web page (http://kirie.me/apps/scratch-csv) and do 4 steps.
1. number of create new accounts.
2. same username
3. same password
4. Click "create csv file" and submit.

After that, you can download new .csv file and upload for your Scratch's classroom site.  
It's very simple way.
