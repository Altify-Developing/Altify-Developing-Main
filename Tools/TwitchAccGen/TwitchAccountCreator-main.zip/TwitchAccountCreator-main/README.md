# Contact me for paid scripts. discord: cryonicx#1337

# Twitch Account Creator 2021

* Captcha Api: https://2captcha.com/
* Proxy Support: http | http/https | socks5 


# Usage

* Type ````pip install -r requirements.txt```` to download modules.
* Type ````python main.py```` to start the script.

# Developer

* *CRYONICX*

* Discord: [@CryonicX](https://discord.com/users/909889971270348832)
* Github: [@CryonicX](https://github.com/CryonicsX)


# Show Your Support

* Donate To Me VIA eth(erc20): ````0xe47148ffa60a38858391b5df32868e1733d4baf2````

# License

* Copyright © 2021 [CRYONICX](https://github.com/CryonicsX).<br />
* This project is [MIT](https://github.com/CryonicsX/TwitchAccountCreator/blob/main/LICENSE) licensed.
