Authored by Joel Christophel, Powerbot user joelamos. <br/>

Detailed setup instructions <a href=http://www.powerbot.org/community/topic/1079099-runescape-account-generator-by-joelamos/>here</a>. <br/> 

Required Selenium jar can be found <a href=http://docs.seleniumhq.org/download/>here</a> under "Selenium Server". Add this file to your project's build path. <br/>
