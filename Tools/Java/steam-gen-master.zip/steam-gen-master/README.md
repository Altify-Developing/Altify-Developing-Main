# steam-gen
steam account generator for jacking old hotmail emails
joint project between: haze & apteryx

## Flags
```java
      parser.register("--digits", true, "<int> Length of SteamIDs to find.");
      parser.register("--accounts", true, "<int>Amount of accounts to generate.");
      parser.register("--verbose", false, "[true] Display the accounts and such.");
      parser.register("--setupcheck", false, "Checks if the user has setup their community profile.");
      parser.register("-oav", false, "Only Accept Valid accounts");
      parser.register("--time", false, "Tells you the time it took to generate the accounts.");
```

## this shid old man
don't use this? (this was made in like, 2014-2015 lol)
```
this method is overly saturated and steam has blocks now to prevent people from doing this on 6 digit accounts and below (you need to contact support with the original CD key)
```
