﻿using System;

class TwitterUser
{
    public string Email
    {
        get; set;
    }

    public string Name
    {
        get; set;
    }

    public string ScreenName
    {
        get; set;
    }

    public string Password
    {
        get; set;
    }

    public string UserId
    {
        get; set;
    }

    public string Suspended
    {
        get; set;
    }

    public DateTime CreatedTime
    {
        get; set;
    }
}
