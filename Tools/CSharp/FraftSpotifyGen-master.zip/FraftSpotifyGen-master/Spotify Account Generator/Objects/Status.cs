﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spotify_Account_Generator
{
    public class Status
    {
        public enum Result
        {
            Success = 1,
            Failure = 2,
            Error = 3
        }
    }
}
