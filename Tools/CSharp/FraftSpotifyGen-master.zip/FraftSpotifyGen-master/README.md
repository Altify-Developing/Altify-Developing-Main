# FraftSpotifyGen
Spotify Account Generator

## How to use?

  Check out my Video: https://youtu.be/tjKpa9a3_Nw

  1. Start the Program
  2. Type the Amount of Accounts you need
  3. Wait for the Program to finish.
  
## In what format are the Accounts exported?

  Accounts are exported in the following format:
  
  Email:Displayname:Username:Password:Gender:Country:Birthdate:Logintoken
  
## Donations
  
  If you want to support me just subscribe to my 
  
  Twitter: https://twitter.com/FraftDev
    
  YouTube: https://www.youtube.com/channel/UCgC7FhdxnW2RvEVE4ZquDkQ
