# Discord-Nitro-QR
Discord QR Scam Image Code Generator &amp; Token + Account Details Grab
![img](https://i.imgur.com/swei0ZN.png)
### About
A tool that automatically Generates a fake Nitro gift QR image to scan . Grabs the Discord Token - Username - Email Address. 
This tool demonstrates how people can trick others into scanning their Discord login QR Code, and gain access to their account..

![img1](https://i.imgur.com/GPjzml1.png)

## Demonstration
-Soon

## Disclaimer
This repository is for research purposes only, the use of this code is your responsibility.

I take NO responsibility and/or liability for how you choose to use any of the source code available here. By using any of the files available in this repository, you understand that you are AGREEING TO USE AT YOUR OWN RISK. Once again, ALL files available here are for EDUCATION and/or RESEARCH purposes ONLY.
