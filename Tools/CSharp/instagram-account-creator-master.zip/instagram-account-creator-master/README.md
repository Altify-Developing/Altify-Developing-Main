# instagram-account-creator
Instagram Account Creator / Generator [Mass Creation]

[![GramCreator Showcase](https://yt-embed.herokuapp.com/embed?v=E2V817iAL8A)](https://www.youtube.com/watch?v=E2V817iAL8A "GramCreator Showcase")

### Intro:

This is a quick look at the Instagram Account Creator called GramCreator. You can find the source at : https://gramcreator.com
| The changelog will be updated with all the features that are added monthly/weekly.

### Reasoning:

It is no longer viable to create your own creator, or use poorly coded public ones. Chrome and Firefox is all detected, and it takes a lot of changing options, recoding binaries and more to prevent Chrome/Fox from being detected and have your accounts be banned eventually. This is why using a off the shelf mass IG account creator like GramCreator is the best option.

### Features:

Phone Verification | 
Our account creator can automatically Phone Verify your accounts with popular SMS sites.

Account Profiling | 
Profile your created IG accounts - add to their biography, link, and even upload custom avatar!

Email Verification | 
Our account creator can email verify accounts with gmail, yahoo, o2.pl, onet.pl & many more.

Perfect Protection | 
Instagram detects many account creators nowadays, this is not the case with ours.

Custom Export Format | 
Export your accounts in any format you want. You can also add all the cookies to the account too.

Follow People | 
Follow people after creation, so that your accounts look more legitimate & authentic!

Generate Random Emails | 
Create random emails. You can use domains such as @gmail, @yahoo, @mail and much more!

Random Chrome Size | 
This helps with success rates. Making randomness high is important to simulate a user.

Random User Agent | 
Our user agent pool is 100+, and we have a tool that will generate you 500+ random user agents.

Mouse Tracking | 
Another feature that simulates a user. Our chrome browser simulate a mouse over the elements.

Email Deletion | 
After a real email is used, it will be removed from the text file to keep track of the used email addresses.

Anti-blacklisting Email | 
We generate a fake email before creating an account, then change it to the real one (preventing blacklist).

Proxy options | 
Choose between using no proxy, using a proxy with user and password, or a proxy with only port.

Manual Accounts Tab | 
Create accounts manually with proxies. This is used for test purposes if you need to create manually

Android Proxy | 
Use mobile phone as a proxy between GramCreator and Instagram. It will turn airplane off and on.

No Update Needed! | 
If SMS service OR email service needed, we are happy to makes these updates without re-download.

Wait After Creation | 
If you need time for your proxies IP to renew/change, we allow an option to wait x seconds after creation.

Add A Referrer | 
Visit a site before visiting Instagram.com, this will allow you to have cookies & increase success rate.

Challenge or PVA | 
Choose between challenge or PVA for phone verification. In case you only need challenge for ex.

Remove Phone | 
If you want to use a phone to solve the challenge, and want to remove it after, this is an option.

Make Account Private | 
Make your Instagram account private after creation. This is a user preference which you can set.

Store SMS Details | 
If you manage a lot of SMS accounts, we allow you to store and remember all your accounts in one.

Choose SMS Country | 
If you want to choose United Kingdom, or USA, you can. A lot of countries for SMS are accepted.

Process Manager | 
See all the GramCreator processes that are simultaneously running, check up as you like.

Single Account Creation | 
Create a single account. This is useful to test if a proxy will work or not to create an account.

Set Thread Count | 
Choose amount of accounts you want to create simultaneously. Allows you to scale tremendously.

Mobile Creation | 
Not only create accounts on Desktop, but choose an option to create the instagram accounts on mobile.
