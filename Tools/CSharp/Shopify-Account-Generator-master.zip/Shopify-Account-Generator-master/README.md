# Shopify-Account-Generator

Generate Shopify accounts with requests in c#.

	- Proxy Support
	- Any Shopify site
